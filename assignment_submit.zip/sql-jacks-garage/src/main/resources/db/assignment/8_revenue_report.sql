select 'Oh no, an SQL just to keep Liquibase happy. ' ||
       '#hiddenErrors #worksOnMyMachine' from (values(0));

-- 6. Create view V_REVENUE_REPORT with three columns: revenue_year, mechanic, revenue

--    This view should sum up all REPAIR_JOB prices by year and Mechanic
--    For example one line returned by this view should look like this:
--    REVENUE_YEAR	MECHANIC	REVENUE
--    2012	        Mike	    263626.75

--CREATE TABLE T (REVENUE_YEAR INT, MECHANIC VARCHAR(50), REVENUE INT(10,2)

--
CREATE VIEW V_REVENUE_REPORT AS SELECT REVENUE_YEAR, MECHANIC, REVENUE AS VALUE FROM 
SELECT SUM(PRICE) FROM REPAIR.JOB GROUP BY END_TIME.YEAR.WORK_LOG, MECHANIC.WORK_LOG;



