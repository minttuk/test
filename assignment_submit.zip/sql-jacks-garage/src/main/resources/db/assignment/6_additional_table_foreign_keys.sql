select 'Oh no, an SQL just to keep Liquibase happy. ' ||
       '#hiddenErrors #worksOnMyMachine' from (values(0));

-- 3. Add foreign keys
ALTER TABLE WORK_LOG ADD FOREIGN KEY (REF_REPAIR_JOB) REFERENCES REPAIR_JOB(ID);
ALTER TABLE SPARE_PART ADD FOREIGN KEY (REF_REPAIR_JOB) REFERENCES REPAIR_JOB(ID);

