select 'Oh no, an SQL just to keep Liquibase happy. ' ||
       '#hiddenErrors #worksOnMyMachine' from (values(0));

-- 4. Migrate work log times from REPAIR_JOB table to WORK_LOG table
INSERT INTO WORK_LOG (START_TIME, END_TIME, DESCRIPTION, REF_REPAIR_JOB, MECHANIC) 
SELECT START_TIME, END_TIME, DESCRIPTION, ID, 'Mike Mechan' 
FROM REPAIR_JOB;

-- 5. Migrate parts from REPAIR_JOB table to the new SPARE_PART table
INSERT INTO SPARE_PART (REF_REPAIR_JOB, NAME) SELECT ID, PARTS 
FROM REPAIR_JOB;
